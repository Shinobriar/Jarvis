# FrameLab — Android GIF & video frame extractor

A small native Android app with a dark UI, built with Java + the Android SDK. No ads, analytics, accounts, native libraries, internet permission, or root access.

## Features

- Open an animated GIF or a locally accessible video from Android's document picker.
- **All frames:** extract the whole GIF/video, at the source resolution.
- **Select frames:** browse a 3-column thumbnail grid in 18-frame pages; tap any number of frames to select/deselect them. Selection persists between pages. There is a frame-number jump field, Select page, and Clear.
- Export as **PNG** (lossless / GIF transparency preserved) or **JPG** (smaller files / GIF transparency becomes white).
- Save a **ZIP** containing consecutively numbered images, or choose a **folder** to create a new folder containing the individual images.
- Progress bar and Cancel button for long exports.
- **Safe with Android three-button navigation:** the app listens to the current system insets and pads the entire UI, including the fixed extraction controls, above the status/navigation bars. Works with gesture navigation as well.
- File access through Android Storage Access Framework (no storage permissions required).

## Build an APK with Android Studio

1. Extract this ZIP onto a computer with **Android Studio** installed.
2. In Android Studio choose **Open** and select the `FrameLab` project folder (the one containing `settings.gradle`).
3. Allow Gradle sync and installation of **Android SDK 35** if prompted. The project uses Android Gradle Plugin **8.7.3** and JDK **17** (or a compatible newer JDK). The matching Gradle distribution is **8.9**.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Install `app/build/outputs/apk/debug/app-debug.apk` on the phone.

> The source project does not include a compiled APK or Gradle distribution, because an Android SDK/Gradle build environment was unavailable during its creation. Gradle needs to be downloaded or configured by Android Studio on first import.

## How to use

1. Tap **Open a GIF or video** and choose a file.
2. Choose **All frames** or **Select frames**. For selection, tap thumbnail frames; switch pages or jump to a particular frame to add more.
3. In the bottom section choose **PNG/JPG** and **ZIP/Folder**.
4. Tap **Extract** and choose the save destination. Keep FrameLab open until the operation finishes.

## Implementation and limitations

- Android 9 (API 28) and newer; compile/target Android SDK 35.
- Android `MediaMetadataRetriever.getFrameAtIndex()` indexes actual video frames. For full video export, batches of up to 2–4 consecutive frames reduce repeated decoder work while keeping memory bounded.
- Some device codecs or media containers do not expose a total video frame count. In that case, FrameLab **clearly labels the estimated count** and uses timestamp-based extraction as a fallback, which may repeat/skip frames for variable-frame-rate video. For such files, all-frames export is an approximation, not an exact exhaustive decoder pass.
- GIF frames are counted from the GIF container and delays, then rendered with Android's built-in `Movie` decoder (which handles transparency, partial updates, and frame disposal). Rare GIFs with unusually tiny or malformed delays might render differently depending on Android's decoder.
- Videos only work if Android's installed platform media extractors/codecs can decode them; video output does not include audio.
- Large exports can use a lot of storage and take a while. Saving a high-resolution video as PNG frames is especially large. Keep the app in the foreground to avoid background process termination.
- This project does **not** request all-files access, INTERNET, or any other dangerous permissions.
- FrameLab keeps selections locally in memory for the current session; it does not upload or transmit any media.

## Source structure

```
FrameLab/
  app/build.gradle
  app/src/main/AndroidManifest.xml
  app/src/main/java/com/shinobriar/framelab/MainActivity.java
  app/src/main/java/com/shinobriar/framelab/GifTimeline.java
  app/src/main/res/...             UI theme + adaptive app icon
  tests/                          GIF timeline smoke test
```

## Tests performed

- The pure-Java GIF timeline parser was compiled and tested against a generated three-frame GIF with different frame durations, size checks, and malformed-input rejection.
- App Java was also syntax/type checked with local Android API *stubs*. **This is not a replacement for a real Android Studio build/device test**, which is still needed.

## Notes for further customization

- App/package ID: `com.shinobriar.framelab`
- Version: `1.0.0` (`versionCode 1`)
- Accent: mint `#A7F5D5`; background `#0C1019`.
- To change the max thumbnails per page, change `PAGE_SIZE` in `MainActivity.java`.
