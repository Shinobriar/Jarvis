package com.shinobriar.framelab;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * GIF container parser: discovers genuine image frames and their animation timestamps.
 * Pixel compositing, transparency and disposal are delegated to Android's Movie decoder.
 * Does not keep GIF image data in memory.
 */
public final class GifTimeline {
    private final List<Integer> sampleMs;
    private final int width;
    private final int height;
    private final long durationMs;

    private GifTimeline(List<Integer> sampleMs, int width, int height, long durationMs) {
        this.sampleMs = Collections.unmodifiableList(sampleMs);
        this.width = width;
        this.height = height;
        this.durationMs = durationMs;
    }

    public int count() { return sampleMs.size(); }
    public int timeMsAt(int index) { return sampleMs.get(index); }
    public int width() { return width; }
    public int height() { return height; }
    public long durationMs() { return durationMs; }

    public static GifTimeline parse(InputStream source) throws IOException {
        if (source == null) throw new IOException("Cannot read GIF");
        try (InputStream input = new BufferedInputStream(source, 32768)) {
            byte[] header = readBytes(input, 6);
            String sig = new String(header, java.nio.charset.StandardCharsets.US_ASCII);
            if (!"GIF87a".equals(sig) && !"GIF89a".equals(sig)) {
                throw new IOException("Not a GIF file");
            }
            int w = word(input), h = word(input);
            if (w <= 0 || h <= 0) throw new IOException("Invalid GIF dimensions");
            int packed = read(input);
            read(input); // background color index
            read(input); // pixel aspect ratio
            if ((packed & 0x80) != 0) skipExactly(input, 3L * (1 << ((packed & 7) + 1)));

            ArrayList<Integer> times = new ArrayList<>();
            long timestamp = 0;
            int pendingDelay = 100; // ms for an unspecified delay
            boolean finished = false;
            while (!finished) {
                int marker = input.read();
                if (marker < 0) break;
                switch (marker) {
                    case 0x21: { // Extension
                        int label = read(input);
                        if (label == 0xF9) {
                            int size = read(input);
                            byte[] gce = readBytes(input, size);
                            if (size >= 4) {
                                int centis = (gce[1] & 255) | ((gce[2] & 255) << 8);
                                pendingDelay = Math.max(20, centis * 10);
                            }
                            skipSubBlocks(input); // normally just the zero terminator
                        } else {
                            skipSubBlocks(input);
                        }
                        break;
                    }
                    case 0x2C: { // Image descriptor; each corresponds to one frame
                        skipExactly(input, 8); // x, y, width, height
                        int localPacked = read(input);
                        if ((localPacked & 0x80) != 0) {
                            skipExactly(input, 3L * (1 << ((localPacked & 7) + 1)));
                        }
                        read(input); // LZW minimum code size
                        skipSubBlocks(input);
                        if (times.size() == Integer.MAX_VALUE || timestamp + pendingDelay > Integer.MAX_VALUE - 1L) {
                            throw new IOException("GIF too long");
                        }
                        // Sampling inside the frame interval avoids boundary rounding errors.
                        times.add((int) (timestamp + pendingDelay / 2));
                        timestamp += pendingDelay;
                        pendingDelay = 100;
                        break;
                    }
                    case 0x3B:
                        finished = true;
                        break;
                    default:
                        throw new IOException("Corrupt GIF: unknown block " + marker);
                }
            }
            if (times.isEmpty()) throw new IOException("GIF contains no image frames");
            return new GifTimeline(times, w, h, timestamp);
        }
    }

    private static int read(InputStream in) throws IOException {
        int b = in.read();
        if (b < 0) throw new IOException("Unexpected end of GIF");
        return b;
    }
    private static int word(InputStream in) throws IOException {
        int lo = read(in), hi = read(in);
        return lo | (hi << 8);
    }
    private static byte[] readBytes(InputStream in, int len) throws IOException {
        byte[] b = new byte[len];
        int off = 0;
        while (off < len) {
            int n = in.read(b, off, len - off);
            if (n <= 0) throw new IOException("Unexpected end of GIF");
            off += n;
        }
        return b;
    }
    private static void skipExactly(InputStream in, long amount) throws IOException {
        while (amount > 0) {
            long n = in.skip(amount);
            if (n <= 0) {
                if (in.read() < 0) throw new IOException("Truncated GIF");
                n = 1;
            }
            amount -= n;
        }
    }
    private static void skipSubBlocks(InputStream in) throws IOException {
        while (true) {
            int size = read(in);
            if (size == 0) return;
            skipExactly(in, size);
        }
    }
}
