package com.shinobriar.framelab;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Movie;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Locale;
import java.util.List;
import java.util.TreeSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Minimal-dependency Android GIF/video frame extractor, API 28+.
 * SAF picker + SAF exports mean no broad storage permission is needed.
 */
public class MainActivity extends Activity {
    private static final int OPEN_INPUT = 101;
    private static final int SAVE_ZIP = 102;
    private static final int SAVE_FOLDER = 103;
    private static final int PAGE_SIZE = 18;

    private static final int BG = Color.rgb(12, 16, 25);
    private static final int PANEL = Color.rgb(23, 30, 43);
    private static final int PANEL_2 = Color.rgb(32, 41, 56);
    private static final int MINT = Color.rgb(167, 245, 213);
    private static final int TEXT = Color.rgb(242, 247, 249);
    private static final int MUTED = Color.rgb(156, 173, 185);
    private static final int OUTLINE = Color.rgb(54, 69, 78);

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final AtomicBoolean cancel = new AtomicBoolean(false);
    private final TreeSet<Integer> chosen = new TreeSet<>();

    private LinearLayout root;
    private ScrollView scroll;
    private LinearLayout content;
    private LinearLayout footer;
    private TextView footerHint;
    private Button exportButton;
    private Button cancelButton;
    private ProgressBar progress;
    private int page = 0;
    private int thumbnailToken = 0;
    private boolean selectionMode = false;
    private boolean png = true;
    private boolean zip = true;
    private boolean exporting = false;
    private MediaSource media;

    private static class MediaSource {
        Uri uri;
        String fileName;
        boolean gif;
        int width;
        int height;
        int frameCount;
        boolean estimated;
        long durationMs;
        GifTimeline gifTimeline;
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        if (Build.VERSION.SDK_INT >= 29) getWindow().setNavigationBarContrastEnforced(false);
        makeRoot();
        renderContent(false);
    }

    @Override public void onConfigurationChanged(Configuration config) {
        super.onConfigurationChanged(config);
        renderContent(false);
    }

    private void makeRoot() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        // Target SDK 35 displays edge-to-edge. Apply real system-bar insets to
        // the WHOLE layout, including the sticky bottom export controls.
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(
                    WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                root.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            } else {
                root.setPadding(insets.getSystemWindowInsetLeft(),
                    insets.getSystemWindowInsetTop(), insets.getSystemWindowInsetRight(),
                    insets.getSystemWindowInsetBottom());
            }
            return insets;
        });

        scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(d(20), d(22), d(20), d(16));
        scroll.addView(content, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        footer = new LinearLayout(this);
        footer.setOrientation(LinearLayout.VERTICAL);
        footer.setPadding(d(20), d(12), d(20), d(12));
        footer.setBackground(background(PANEL, 0, 0));
        root.addView(footer, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
        root.requestApplyInsets();
    }

    private void renderContent(boolean preserveScroll) {
        int scrollY = preserveScroll ? scroll.getScrollY() : 0;
        thumbnailToken++;
        content.removeAllViews();
        renderHeader();
        renderFilePicker();
        if (media != null) {
            renderMediaDetails();
            renderModeControls();
            if (selectionMode) renderSelectionArea();
            else renderAllFramesArea();
        } else {
            renderWelcome();
        }
        renderFooter();
        scroll.post(() -> scroll.scrollTo(0, scrollY));
    }

    private void renderHeader() {
        LinearLayout line = row();
        TextView logo = t("◧", 32, MINT, true);
        line.addView(logo);
        LinearLayout words = column();
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.leftMargin = d(11);
        TextView title = t("FrameLab", 27, TEXT, true);
        title.setLetterSpacing(-.035f);
        words.addView(title);
        words.addView(t("EVERY FRAME. YOUR CHOICE.", 10, MINT, true));
        line.addView(words, lp);
        content.addView(line);
        spacer(content, 23);
    }

    private void renderFilePicker() {
        LinearLayout picker = column();
        picker.setGravity(Gravity.CENTER);
        picker.setPadding(d(18), d(23), d(18), d(23));
        picker.setBackground(background(PANEL, d(24), d(1), OUTLINE));
        TextView symbol = t("↥", 34, MINT, true);
        symbol.setGravity(Gravity.CENTER);
        picker.addView(symbol);
        spacer(picker, 3);
        TextView primary = t(media == null ? "Open a GIF or video" : "Change source file", 18, TEXT, true);
        primary.setGravity(Gravity.CENTER);
        picker.addView(primary);
        spacer(picker, 5);
        TextView secondary = t(media == null
            ? "Choose a file from your device" : "Tap to select a different GIF or video",
            12, MUTED, false);
        secondary.setGravity(Gravity.CENTER);
        picker.addView(secondary);
        picker.setOnClickListener(v -> pickInput());
        content.addView(picker, new LinearLayout.LayoutParams(-1, -2));
        spacer(content, 20);
    }

    private void renderWelcome() {
        TextView label = t("MADE FOR THE DETAILS", 11, MINT, true);
        content.addView(label);
        spacer(content, 12);
        addFeature("01", "All frames", "Export the complete animation or video.");
        addFeature("02", "Pick your favorites", "Browse frames and tap exactly the ones you want.");
        addFeature("03", "PNG, JPG, ZIP", "Save images individually or in one ZIP archive.");
    }

    private void addFeature(String number, String name, String description) {
        LinearLayout line = row();
        line.setPadding(d(15), d(15), d(15), d(15));
        line.setBackground(background(PANEL, d(17), 0));
        TextView mark = t(number, 14, MINT, true);
        mark.setWidth(d(44));
        line.addView(mark);
        LinearLayout words = column();
        words.addView(t(name, 15, TEXT, true));
        spacer(words, 3);
        words.addView(t(description, 12, MUTED, false));
        line.addView(words, new LinearLayout.LayoutParams(-1, -2));
        content.addView(line);
        spacer(content, 9);
    }

    private void renderMediaDetails() {
        content.addView(t("CURRENT FILE", 10, MINT, true));
        spacer(content, 7);
        TextView name = t(media.fileName, 18, TEXT, true);
        name.setMaxLines(2);
        content.addView(name);
        spacer(content, 8);
        LinearLayout chips = row();
        chips.addView(tag(media.gif ? "GIF" : "VIDEO"));
        spacerHorizontal(chips, 8);
        chips.addView(tag(number(media.frameCount) + (media.estimated ? " ~" : "") + " frames"));
        spacerHorizontal(chips, 8);
        chips.addView(tag(media.width + " × " + media.height));
        content.addView(chips);
        if (media.estimated) {
            spacer(content, 8);
            content.addView(t("Frame count is estimated for this file; exact indexing is unavailable on this device.",
                11, MUTED, false));
        }
        spacer(content, 24);
    }

    private void renderModeControls() {
        content.addView(t("WHAT DO YOU WANT TO EXTRACT?", 11, MINT, true));
        spacer(content, 11);
        LinearLayout modes = row();
        Button all = toggle("All frames", !selectionMode, () -> {
            if (exporting) return;
            selectionMode = false;
            renderContent(true);
        });
        Button selected = toggle("Select frames", selectionMode, () -> {
            if (exporting) return;
            selectionMode = true;
            renderContent(true);
        });
        modes.addView(all, new LinearLayout.LayoutParams(0, d(48), 1f));
        spacerHorizontal(modes, 8);
        modes.addView(selected, new LinearLayout.LayoutParams(0, d(48), 1f));
        content.addView(modes);
        spacer(content, 17);
    }

    private void renderAllFramesArea() {
        LinearLayout panel = column();
        panel.setPadding(d(18), d(20), d(18), d(20));
        panel.setBackground(background(PANEL, d(18), 0));
        panel.addView(t("Everything, in order", 17, TEXT, true));
        spacer(panel, 6);
        panel.addView(t("All " + number(media.frameCount) + " frames will be exported at original resolution.",
            13, MUTED, false));
        if (media.frameCount > 600) {
            spacer(panel, 10);
            panel.addView(t("Heads up: full-length videos can create thousands of images and use lots of storage.",
                12, MINT, false));
        }
        content.addView(panel);
        spacer(content, 12);
    }

    private void renderSelectionArea() {
        content.addView(t("Tap any frames you want. Move between pages to pick more.", 12, MUTED, false));
        spacer(content, 15);

        LinearLayout headline = row();
        headline.setGravity(Gravity.CENTER_VERTICAL);
        TextView pager = t("FRAMES " + (page * PAGE_SIZE + 1) + "–" +
            Math.min(media.frameCount, (page + 1) * PAGE_SIZE), 11, MINT, true);
        headline.addView(pager, new LinearLayout.LayoutParams(0, -2, 1));
        Button pageAll = smallButton("Select page", () -> {
            if (exporting) return;
            int first = page * PAGE_SIZE;
            for (int i = first; i < Math.min(first + PAGE_SIZE, media.frameCount); i++) chosen.add(i);
            renderContent(true);
        });
        headline.addView(pageAll);
        spacerHorizontal(headline, 7);
        Button clear = smallButton("Clear", () -> {
            if (exporting) return;
            chosen.clear();
            renderContent(true);
        });
        headline.addView(clear);
        content.addView(headline);
        spacer(content, 11);

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(3);
        int screen = root.getWidth() > 0 ? root.getWidth() - root.getPaddingLeft() - root.getPaddingRight()
            : getResources().getDisplayMetrics().widthPixels;
        int avail = Math.max(d(255), screen - d(40) - d(12));
        int w = (avail - d(12)) / 3;
        final int start = page * PAGE_SIZE;
        int n = Math.min(PAGE_SIZE, media.frameCount - start);
        final ArrayList<ImageView> thumbViews = new ArrayList<>();
        for (int k = 0; k < n; k++) {
            final int frameIndex = start + k;
            FrameLayout tile = new FrameLayout(this);
            tile.setBackground(background(PANEL, d(11), d(1),
                chosen.contains(frameIndex) ? MINT : OUTLINE));
            tile.setClipToOutline(true);
            ImageView img = new ImageView(this);
            img.setScaleType(ImageView.ScaleType.FIT_CENTER);
            img.setBackgroundColor(PANEL_2);
            FrameLayout.LayoutParams imgParams = new FrameLayout.LayoutParams(-1, -1);
            tile.addView(img, imgParams);
            thumbViews.add(img);

            TextView count = t("#" + (frameIndex + 1), 11, TEXT, true);
            count.setPadding(d(6), d(3), d(6), d(3));
            count.setBackground(background(0xD80C1019, d(6), 0));
            FrameLayout.LayoutParams countParams = new FrameLayout.LayoutParams(-2, -2,
                Gravity.BOTTOM | Gravity.LEFT);
            countParams.setMargins(d(5), 0, 0, d(5));
            tile.addView(count, countParams);

            TextView checked = t(chosen.contains(frameIndex) ? "✓" : "+", 15,
                chosen.contains(frameIndex) ? BG : TEXT, true);
            checked.setGravity(Gravity.CENTER);
            checked.setBackground(background(chosen.contains(frameIndex) ? MINT : 0xD80C1019,
                d(99), 0));
            FrameLayout.LayoutParams checkParams = new FrameLayout.LayoutParams(d(27), d(27),
                Gravity.TOP | Gravity.RIGHT);
            checkParams.setMargins(0, d(5), d(5), 0);
            tile.addView(checked, checkParams);

            tile.setOnClickListener(v -> {
                if (exporting) return;
                if (!chosen.add(frameIndex)) chosen.remove(frameIndex);
                boolean active = chosen.contains(frameIndex);
                tile.setBackground(background(PANEL, d(11), d(2), active ? MINT : OUTLINE));
                checked.setText(active ? "✓" : "+");
                checked.setTextColor(active ? BG : TEXT);
                checked.setBackground(background(active ? MINT : 0xD80C1019, d(99), 0));
                updateFooterCount();
            });
            GridLayout.LayoutParams gp = new GridLayout.LayoutParams(
                GridLayout.spec(k / 3), GridLayout.spec(k % 3));
            gp.width = w;
            gp.height = Math.max(d(86), (int) (w * 0.88));
            gp.setMargins(d(2), d(2), d(2), d(2));
            grid.addView(tile, gp);
        }
        content.addView(grid);
        startPageThumbnails(start, thumbViews);
        spacer(content, 13);

        LinearLayout pageButtons = row();
        pageButtons.setGravity(Gravity.CENTER_VERTICAL);
        Button previous = smallButton("← Previous", () -> {
            if (page == 0 || exporting) return;
            page--;
            renderContent(true);
        });
        previous.setEnabled(page > 0);
        previous.setAlpha(page > 0 ? 1f : .4f);
        pageButtons.addView(previous);
        TextView current = t((page + 1) + " / " + ((media.frameCount + PAGE_SIZE - 1) / PAGE_SIZE),
            12, TEXT, true);
        current.setGravity(Gravity.CENTER);
        pageButtons.addView(current, new LinearLayout.LayoutParams(0, -2, 1));
        Button next = smallButton("Next →", () -> {
            if (exporting || (page + 1) * PAGE_SIZE >= media.frameCount) return;
            page++;
            renderContent(true);
        });
        boolean hasNext = (page + 1) * PAGE_SIZE < media.frameCount;
        next.setEnabled(hasNext);
        next.setAlpha(hasNext ? 1f : .4f);
        pageButtons.addView(next);
        content.addView(pageButtons);
        spacer(content, 15);

        LinearLayout jump = row();
        jump.setGravity(Gravity.CENTER_VERTICAL);
        jump.addView(t("Go to frame", 12, MUTED, false));
        spacerHorizontal(jump, 9);
        EditText field = new EditText(this);
        field.setSingleLine(true);
        field.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        field.setTextColor(TEXT);
        field.setHintTextColor(MUTED);
        field.setTextSize(13);
        field.setHint("1–" + media.frameCount);
        field.setPadding(d(10), 0, d(10), 0);
        field.setBackground(background(PANEL_2, d(9), d(1), OUTLINE));
        jump.addView(field, new LinearLayout.LayoutParams(0, d(41), 1));
        spacerHorizontal(jump, 8);
        jump.addView(smallButton("Go", () -> {
            if (exporting) return;
            try {
                int target = Integer.parseInt(field.getText().toString().trim()) - 1;
                if (target < 0 || target >= media.frameCount) throw new NumberFormatException();
                page = target / PAGE_SIZE;
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) imm.hideSoftInputFromWindow(field.getWindowToken(), 0);
                renderContent(true);
            } catch (NumberFormatException err) {
                Toast.makeText(this, "Enter a frame number from 1 to " + media.frameCount,
                    Toast.LENGTH_SHORT).show();
            }
        }));
        content.addView(jump);
        spacer(content, 14);
    }

    private void startPageThumbnails(int start, ArrayList<ImageView> targets) {
        final int token = thumbnailToken;
        final MediaSource source = media;
        worker.execute(() -> {
            MediaMetadataRetriever retriever = null;
            Movie movie = null;
            try {
                if (source.gif) {
                    try (InputStream in = getContentResolver().openInputStream(source.uri)) {
                        movie = Movie.decodeStream(in);
                    }
                    if (movie == null) throw new IOException("Cannot decode GIF");
                } else {
                    retriever = new MediaMetadataRetriever();
                    retriever.setDataSource(this, source.uri);
                }
                for (int k = 0; k < targets.size(); k++) {
                    if (token != thumbnailToken || media != source) return;
                    Bitmap small = null;
                    try {
                        if (source.gif) {
                            small = renderGifFrame(movie, source, start + k, 220, 150, false);
                        } else {
                            Bitmap full = videoFrame(retriever, source, start + k);
                            if (full != null) {
                                int w = full.getWidth(), h = full.getHeight();
                                float ratio = Math.min(220f / w, 150f / h);
                                small = Bitmap.createScaledBitmap(full,
                                    Math.max(1, (int) (w * ratio)),
                                    Math.max(1, (int) (h * ratio)), true);
                                if (small != full) full.recycle();
                            }
                        }
                    } catch (Exception ignored) { /* keep placeholder for failed thumbnails */ }
                    final Bitmap thumb = small;
                    final ImageView image = targets.get(k);
                    main.post(() -> {
                        if (token == thumbnailToken && media == source && thumb != null) {
                            image.setImageBitmap(thumb);
                        } else if (thumb != null) {
                            thumb.recycle();
                        }
                    });
                }
            } catch (Exception ignored) { /* invalid frame placeholders are harmless */ }
            finally { if (retriever != null) { try { retriever.release(); } catch (IOException ignored) {} } }
        });
    }

    private void renderFooter() {
        footer.removeAllViews();
        if (media == null) {
            footer.addView(t("No file selected yet", 12, MUTED, false));
            return;
        }
        LinearLayout options = row();
        options.setGravity(Gravity.CENTER_VERTICAL);
        options.addView(t("FORMAT", 10, MUTED, true));
        spacerHorizontal(options, 10);
        options.addView(toggleSmall("PNG", png, () -> { if (!exporting) { png = true; renderFooter(); } }));
        spacerHorizontal(options, 5);
        options.addView(toggleSmall("JPG", !png, () -> { if (!exporting) { png = false; renderFooter(); } }));
        options.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1));
        options.addView(t("SAVE", 10, MUTED, true));
        spacerHorizontal(options, 10);
        options.addView(toggleSmall("ZIP", zip, () -> { if (!exporting) { zip = true; renderFooter(); } }));
        spacerHorizontal(options, 5);
        options.addView(toggleSmall("Folder", !zip, () -> { if (!exporting) { zip = false; renderFooter(); } }));
        footer.addView(options);
        spacer(footer, 12);

        LinearLayout bottom = row();
        bottom.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout info = column();
        footerHint = t("", 12, MUTED, false);
        info.addView(footerHint);
        bottom.addView(info, new LinearLayout.LayoutParams(0, -2, 1));
        exportButton = new Button(this);
        exportButton.setText("Extract  →");
        exportButton.setTextColor(BG);
        exportButton.setAllCaps(false);
        exportButton.setTextSize(15);
        exportButton.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        exportButton.setBackground(background(MINT, d(14), 0));
        exportButton.setOnClickListener(v -> prepareExport());
        bottom.addView(exportButton, new LinearLayout.LayoutParams(d(138), d(49)));
        footer.addView(bottom);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(1000);
        progress.setProgressTintList(android.content.res.ColorStateList.valueOf(MINT));
        LinearLayout.LayoutParams progressLp = new LinearLayout.LayoutParams(-1, d(3));
        progressLp.topMargin = d(10);
        footer.addView(progress, progressLp);
        progress.setVisibility(exporting ? View.VISIBLE : View.GONE);
        cancelButton = smallButton("Cancel extraction", () -> {
            cancel.set(true);
            cancelButton.setEnabled(false);
            cancelButton.setText("Cancelling…");
        });
        cancelButton.setTextColor(MINT);
        LinearLayout.LayoutParams cancelLp = new LinearLayout.LayoutParams(-2, d(36));
        cancelLp.gravity = Gravity.CENTER_HORIZONTAL;
        footer.addView(cancelButton, cancelLp);
        cancelButton.setVisibility(exporting ? View.VISIBLE : View.GONE);
        updateFooterCount();
    }

    private void updateFooterCount() {
        if (footerHint == null || media == null) return;
        int count = selectionMode ? chosen.size() : media.frameCount;
        if (exporting) {
            exportButton.setEnabled(false);
            exportButton.setAlpha(.5f);
        } else {
            footerHint.setText(selectionMode
                ? (count == 0 ? "Choose at least one frame" : number(count) + " selected")
                : number(count) + " frames ready");
            exportButton.setEnabled(count > 0);
            exportButton.setAlpha(count > 0 ? 1f : .45f);
        }
    }

    private void pickInput() {
        if (exporting) { toast("Cancel the current export first"); return; }
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/gif", "video/*"});
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivityForResult(intent, OPEN_INPUT);
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (result != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (request == OPEN_INPUT) {
            loadFile(uri);
        } else if (request == SAVE_ZIP || request == SAVE_FOLDER) {
            startExport(uri, request == SAVE_ZIP);
        }
    }

    private void loadFile(Uri uri) {
        if (exporting) return;
        toast("Reading file…");
        final int token = ++thumbnailToken;
        worker.execute(() -> {
            try {
                MediaSource found = inspect(uri);
                main.post(() -> {
                    if (token != thumbnailToken) return;
                    media = found;
                    page = 0;
                    chosen.clear();
                    selectionMode = false;
                    renderContent(false);
                });
            } catch (Exception e) {
                main.post(() -> error("Could not open file", e));
            }
        });
    }

    private MediaSource inspect(Uri uri) throws Exception {
        MediaSource result = new MediaSource();
        result.uri = uri;
        result.fileName = fileName(uri);
        String mime = getContentResolver().getType(uri);
        result.gif = (mime != null && mime.equalsIgnoreCase("image/gif")) ||
            result.fileName.toLowerCase(Locale.ROOT).endsWith(".gif");
        if (result.gif) {
            result.gifTimeline = GifTimeline.parse(getContentResolver().openInputStream(uri));
            result.frameCount = result.gifTimeline.count();
            result.durationMs = result.gifTimeline.durationMs();
            result.width = result.gifTimeline.width();
            result.height = result.gifTimeline.height();
            // Verify Android can actually render the GIF before displaying options.
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (Movie.decodeStream(in) == null) throw new IOException("GIF decoder cannot open this file");
            }
        } else {
            MediaMetadataRetriever mmr = new MediaMetadataRetriever();
            try {
                mmr.setDataSource(this, uri);
                result.width = intOr(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH), 0);
                result.height = intOr(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT), 0);
                result.durationMs = Math.max(1, intOr(mmr.extractMetadata(
                    MediaMetadataRetriever.METADATA_KEY_DURATION), 0));
                result.frameCount = intOr(mmr.extractMetadata(
                    MediaMetadataRetriever.METADATA_KEY_VIDEO_FRAME_COUNT), 0);
                if (result.frameCount <= 0) {
                    result.estimated = true;
                    float fps = estimateFps(uri);
                    result.frameCount = Math.max(1,
                        (int) Math.min(1_000_000, Math.ceil(result.durationMs * fps / 1000d)));
                }
                if (result.width <= 0 || result.height <= 0) throw new IOException("Not a supported video");
            } finally { mmr.release(); }
        }
        return result;
    }

    private float estimateFps(Uri uri) {
        MediaExtractor extractor = new MediaExtractor();
        try {
            extractor.setDataSource(this, uri, null);
            for (int i = 0; i < extractor.getTrackCount(); i++) {
                MediaFormat fmt = extractor.getTrackFormat(i);
                String mime = fmt.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("video/")) {
                    if (fmt.containsKey(MediaFormat.KEY_FRAME_RATE)) {
                        return Math.max(1, Math.min(240, fmt.getInteger(MediaFormat.KEY_FRAME_RATE)));
                    }
                }
            }
        } catch (Exception ignored) { }
        finally { extractor.release(); }
        return 30f;
    }

    private void prepareExport() {
        if (media == null || exporting) return;
        int count = selectionMode ? chosen.size() : media.frameCount;
        if (count == 0) { toast("Select at least one frame"); return; }
        if (count > 1500) {
            new AlertDialog.Builder(this)
                .setTitle("Export " + number(count) + " frames?")
                .setMessage("This could take a while and produce a very large file. Keep the app open during extraction.")
                .setNegativeButton("Not now", null)
                .setPositiveButton("Continue", (dialog, which) -> openExportPicker())
                .show();
        } else openExportPicker();
    }

    private void openExportPicker() {
        if (zip) {
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("application/zip");
            intent.putExtra(Intent.EXTRA_TITLE, safeBaseName() + "_frames.zip");
            intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            startActivityForResult(intent, SAVE_ZIP);
        } else {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            startActivityForResult(intent, SAVE_FOLDER);
        }
    }

    private void startExport(Uri output, boolean asZip) {
        if (media == null || exporting) return;
        final MediaSource source = media;
        final boolean exportPng = png;
        final boolean useChosen = selectionMode;
        final int[] indices = useChosen ? new int[chosen.size()] : null;
        if (indices != null) {
            int k = 0;
            for (int id : chosen) indices[k++] = id;
        }
        final int total = indices == null ? source.frameCount : indices.length;
        if (total == 0) return;
        exporting = true;
        cancel.set(false);
        renderFooter();
        footerHint.setText("Preparing export…");
        final String base = safeBaseName();
        worker.execute(() -> {
            int done = 0;
            Uri outputTarget = output;
            boolean completed = false;
            boolean wasCancelled = false;
            ZipOutputStream zipStream = null;
            MediaMetadataRetriever retriever = null;
            Movie movie = null;
            Bitmap gifCanvas = null;
            Canvas gifPainter = null;
            ArrayList<Bitmap> videoBatch = null;
            long lastTick = 0;
            try {
                if (asZip) {
                    OutputStream out = getContentResolver().openOutputStream(outputTarget, "w");
                    if (out == null) throw new IOException("Cannot write the ZIP file");
                    zipStream = new ZipOutputStream(new BufferedOutputStream(out, 65536));
                } else {
                    Uri root = DocumentsContract.buildDocumentUriUsingTree(output,
                        DocumentsContract.getTreeDocumentId(output));
                    outputTarget = DocumentsContract.createDocument(getContentResolver(), root,
                        DocumentsContract.Document.MIME_TYPE_DIR,
                        base + "_frames_" + System.currentTimeMillis());
                    if (outputTarget == null) throw new IOException("Cannot create destination folder");
                }

                if (source.gif) {
                    try (InputStream in = getContentResolver().openInputStream(source.uri)) {
                        movie = Movie.decodeStream(in);
                    }
                    if (movie == null) throw new IOException("Cannot decode GIF");
                    long pixels = (long) source.width * source.height;
                    if (pixels > 30_000_000L) throw new IOException("GIF dimensions exceed safe memory limit");
                    gifCanvas = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888);
                    gifPainter = new Canvas(gifCanvas);
                } else {
                    retriever = new MediaMetadataRetriever();
                    retriever.setDataSource(this, source.uri);
                }
                for (int ordinal = 0; ordinal < total; ordinal++) {
                    if (cancel.get()) { wasCancelled = true; break; }
                    int index = indices == null ? ordinal : indices[ordinal];
                    Bitmap frame;
                    if (source.gif) {
                        gifPainter.drawColor(exportPng ? Color.TRANSPARENT : Color.WHITE,
                            PorterDuff.Mode.SRC);
                        movie.setTime(source.gifTimeline.timeMsAt(index));
                        movie.draw(gifPainter, 0, 0);
                        frame = gifCanvas;
                    } else {
                        // Android recommends batched frame-index retrieval for nearby
                        // video frames. Bound each batch to avoid excessive RAM use.
                        if (!source.estimated && indices == null &&
                            (videoBatch == null || videoBatch.isEmpty())) {
                            int size = (long) source.width * source.height > 2_500_000L ? 2 : 4;
                            try {
                                List<Bitmap> decoded = retriever.getFramesAtIndex(index,
                                    Math.min(size, total - ordinal));
                                if (decoded != null && !decoded.isEmpty()) {
                                    videoBatch = new ArrayList<>(decoded);
                                }
                            } catch (RuntimeException ignored) {
                                videoBatch = null; // fallback to individual frames
                            }
                        }
                        frame = videoBatch != null && !videoBatch.isEmpty()
                            ? videoBatch.remove(0)
                            : videoFrame(retriever, source, index);
                        if (frame == null) throw new IOException("Could not decode video frame #" + (index + 1));
                    }
                    String extension = exportPng ? ".png" : ".jpg";
                    String entryName = String.format(Locale.US, "frame_%07d%s", index + 1, extension);
                    try {
                        if (asZip) {
                            zipStream.putNextEntry(new ZipEntry(entryName));
                            if (!frame.compress(exportPng ? Bitmap.CompressFormat.PNG : Bitmap.CompressFormat.JPEG,
                                94, zipStream)) throw new IOException("Image encoding failed");
                            zipStream.closeEntry();
                        } else {
                            Uri entry = DocumentsContract.createDocument(getContentResolver(), outputTarget,
                                exportPng ? "image/png" : "image/jpeg", entryName);
                            if (entry == null) throw new IOException("Cannot create " + entryName);
                            try (OutputStream os = getContentResolver().openOutputStream(entry, "w")) {
                                if (os == null) throw new IOException("Cannot write " + entryName);
                                if (!frame.compress(exportPng ? Bitmap.CompressFormat.PNG : Bitmap.CompressFormat.JPEG,
                                    94, os)) throw new IOException("Image encoding failed");
                            }
                        }
                    } finally {
                        if (!source.gif) frame.recycle();
                    }
                    done++;
                    long now = SystemClock.elapsedRealtime();
                    if (now - lastTick > 140 || done == total) {
                        final int current = done;
                        main.post(() -> {
                            if (progress != null) progress.setProgress((int) (1000L * current / total));
                            if (footerHint != null) footerHint.setText(number(current) + " / " + number(total) + " frames");
                        });
                        lastTick = now;
                    }
                }
                completed = !wasCancelled;
            } catch (Throwable e) {
                final String msg = readableError(e);
                main.post(() -> new AlertDialog.Builder(this)
                    .setTitle("Export failed")
                    .setMessage(msg + "\n\nAny images already written might still be in the destination.")
                    .setPositiveButton("OK", null).show());
            } finally {
                if (zipStream != null) try { zipStream.close(); } catch (IOException ignored) { }
                if (retriever != null) { try { retriever.release(); } catch (IOException ignored) {} }
                if (videoBatch != null) for (Bitmap unused : videoBatch) unused.recycle();
                if (gifCanvas != null) gifCanvas.recycle();
                final boolean success = completed;
                final boolean stopped = wasCancelled;
                final int exported = done;
                main.post(() -> {
                    exporting = false;
                    renderFooter();
                    if (success) new AlertDialog.Builder(this)
                        .setTitle("Frames extracted ✓")
                        .setMessage(number(exported) + " images saved " + (asZip ? "to your ZIP." : "in your folder."))
                        .setPositiveButton("Nice!", null).show();
                    else if (stopped) toast("Cancelled after " + number(exported) + " frames. Partial output may remain.");
                });
            }
        });
    }

    private static Bitmap videoFrame(MediaMetadataRetriever retriever, MediaSource source, int index) {
        if (!source.estimated) {
            return retriever.getFrameAtIndex(index);
        }
        long timeUs = Math.min(source.durationMs * 1000L - 1,
            (long) (index * (source.durationMs * 1000d / source.frameCount)));
        return retriever.getFrameAtTime(Math.max(0, timeUs), MediaMetadataRetriever.OPTION_CLOSEST);
    }

    private static Bitmap renderGifFrame(Movie movie, MediaSource source, int index,
                                          int w, int h, boolean fullSize) {
        int width = fullSize ? source.width : w;
        int height = fullSize ? source.height : h;
        Bitmap target = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(target);
        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        if (!fullSize) {
            float scale = Math.min(width / (float) source.width, height / (float) source.height);
            canvas.translate((width - source.width * scale) / 2,
                (height - source.height * scale) / 2);
            canvas.scale(scale, scale);
        }
        movie.setTime(source.gifTimeline.timeMsAt(index));
        movie.draw(canvas, 0, 0);
        return target;
    }

    private String fileName(Uri uri) {
        String name = null;
        try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME},
            null, null, null)) {
            if (c != null && c.moveToFirst()) name = c.getString(0);
        } catch (Exception ignored) { }
        return (name == null || name.trim().isEmpty()) ? "untitled" : name;
    }

    private String safeBaseName() {
        String s = media == null ? "frames" : media.fileName;
        int dot = s.lastIndexOf('.');
        if (dot > 0) s = s.substring(0, dot);
        s = s.replaceAll("[^a-zA-Z0-9._-]+", "_");
        return s.length() > 65 ? s.substring(0, 65) : (s.isEmpty() ? "frames" : s);
    }

    private void error(String title, Exception e) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(readableError(e))
            .setPositiveButton("OK", null).show();
    }
    private static String readableError(Throwable e) {
        String msg = e.getMessage();
        return (msg == null || msg.trim().isEmpty()) ? e.getClass().getSimpleName() : msg;
    }
    private static int intOr(String v, int other) {
        if (v == null) return other;
        try { return Integer.parseInt(v); } catch (NumberFormatException e) { return other; }
    }
    private static String number(int n) { return String.format(Locale.US, "%,d", n); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); return l; }
    private int d(float dp) { return (int) (getResources().getDisplayMetrics().density * dp + 0.5f); }
    private TextView t(String text, int sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(color);
        v.setTextSize(sp);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }
    private void spacer(LinearLayout parent, int dp) { parent.addView(new View(this), new LinearLayout.LayoutParams(1, d(dp))); }
    private void spacerHorizontal(LinearLayout parent, int dp) { parent.addView(new View(this), new LinearLayout.LayoutParams(d(dp), 1)); }
    private GradientDrawable background(int color, int radius, int border) {
        return background(color, radius, border, OUTLINE);
    }
    private GradientDrawable background(int color, int radius, int border, int strokeColor) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(radius);
        if (border > 0) bg.setStroke(d(border), strokeColor);
        return bg;
    }
    private TextView tag(String value) {
        TextView tag = t(value, 11, MUTED, true);
        tag.setPadding(d(10), d(6), d(10), d(6));
        tag.setBackground(background(PANEL, d(7), 0));
        return tag;
    }
    private Button toggle(String label, boolean active, Runnable action) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(active ? BG : MUTED);
        b.setBackground(background(active ? MINT : PANEL, d(12), active ? 0 : 1));
        b.setOnClickListener(v -> action.run());
        return b;
    }
    private Button toggleSmall(String label, boolean active, Runnable action) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(label);
        b.setTextSize(11);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(d(9), 0, d(9), 0);
        b.setTextColor(active ? BG : MUTED);
        b.setBackground(background(active ? MINT : PANEL_2, d(7), 0));
        b.setOnClickListener(v -> action.run());
        b.setLayoutParams(new LinearLayout.LayoutParams(-2, d(34)));
        return b;
    }
    private Button smallButton(String label, Runnable action) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(label);
        b.setTextColor(TEXT);
        b.setTextSize(11);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(d(12), 0, d(12), 0);
        b.setBackground(background(PANEL_2, d(9), 0));
        b.setLayoutParams(new LinearLayout.LayoutParams(-2, d(36)));
        b.setOnClickListener(v -> action.run());
        return b;
    }

    @Override protected void onDestroy() {
        thumbnailToken++;
        cancel.set(true);
        worker.shutdownNow();
        super.onDestroy();
    }
}
