import com.shinobriar.framelab.GifTimeline;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Arrays;

public final class GifTimelineSmokeTest {
    public static void main(String[] args) throws Exception {
        GifTimeline gif;
        try (FileInputStream in = new FileInputStream(args[0])) {
            gif = GifTimeline.parse(in);
        }
        require(gif.count() == 3, "Expected 3 frames, got " + gif.count());
        require(gif.width() == 10 && gif.height() == 8, "Incorrect dimensions");
        require(gif.timeMsAt(0) == 50, "Wrong first sample");
        require(gif.timeMsAt(1) == 225, "Wrong second sample");
        require(gif.timeMsAt(2) == 385, "Wrong third sample");
        require(gif.durationMs() == 420, "Wrong total duration: " + gif.durationMs());
        boolean rejected = false;
        try { GifTimeline.parse(new ByteArrayInputStream(new byte[]{0,1,2,3,4,5})); }
        catch (IOException expected) { rejected = true; }
        require(rejected, "Non-GIF input was accepted");
        System.out.println("GIF timeline PASS: correct 3 frames, timing, size, and malformed input check");
    }
    private static void require(boolean ok, String error) {
        if (!ok) throw new AssertionError(error);
    }
}
