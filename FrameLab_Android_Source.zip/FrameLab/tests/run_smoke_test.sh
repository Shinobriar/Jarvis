#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
javac -d "$OUT" app/src/main/java/com/shinobriar/framelab/GifTimeline.java tests/GifTimelineSmokeTest.java
java -cp "$OUT" GifTimelineSmokeTest tests/sample_3_frames.gif
